from app import foo
from app import bar

print ("main")
foo.doFoo()
bar.doBar()

