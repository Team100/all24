from app import foo

def doBar():
    print("doBar")
    foo.doFoo()
